/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.daa;

/**
 *
 * @author DELL
 */
public class DAA {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
