/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author DELL
 */
//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

//class Edge {
//    int src;
//    int dest;
//    int weight;
//
//    public Edge(int src, int dest, int weight) {
//        this.src = src;
//        this.dest = dest;
//        this.weight = weight;
//    }
//    @Override
//    public boolean equals(Object o) {
//        if (this == o) return true;
//        if (o == null || getClass() != o.getClass()) return false;
//        Edge edge = (Edge) o;
//        return src == edge.src && dest == edge.dest;
//    }
//
//    @Override
//    public int hashCode() {
//        return 31 * src + dest;
//    }
//}
//class Edge {
//    int src, dest, weight;
//    Edge(int src, int dest, int weight) {
//    this.src = src;
//    this.dest = dest;
//    this.weight = weight;
//}
//
//@Override
//public boolean equals(Object o) {
//    if (this == o) return true;
//    if (o == null || getClass() != o.getClass()) return false;
//    Edge edge = (Edge) o;
//    return src == edge.src && dest == edge.dest;
//}
//
//@Override
//public int hashCode() {
//    return 31 * src + dest;
//}
class Edge {
    int src, dest, weight;

    Edge(int src, int dest, int weight) {
        this.src = src;
        this.dest = dest;
        this.weight = weight;
    }

    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Edge edge = (Edge) obj;
        return src == edge.src && dest == edge.dest && weight == edge.weight;
    }

    public int hashCode() {
        return 31 * (31 * src + dest) + weight;
    }

//    int src, dest, weight;
//
//    Edge(int src, int dest, int weight) {
//        this.src = src;
//        this.dest = dest;
//        this.weight = weight;
//    }
//
//    @Override
//    public boolean equals(Object o) {
//        if (this == o) return true;
//        if (o == null || getClass() != o.getClass()) return false;
//        Edge edge = (Edge) o;
//        return src == edge.src && dest == edge.dest;
//    }
//
//    @Override
//    public int hashCode() {
//        return 31 * src + dest;
//    }
}
