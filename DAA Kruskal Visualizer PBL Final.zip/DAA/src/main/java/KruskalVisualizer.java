import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

class KruskalVisualizer extends JFrame {
    private List<Edge> edges = new ArrayList<>();
    private List<Edge> mstEdges = new ArrayList<>();
    private int[] parent;
    private int[] rank;
    private int V = 0;
    private KruskalPanel kruskalPanel;
    private JLabel totalCostLabel;
    private int totalCost = 0;
    private JTextField nodesTextField;
    private JTextField edgeSrcTextField;
    private JTextField edgeDestTextField;
    private JTextField edgeWeightTextField;
    private JTextField deleteNodeTextField;

    public KruskalVisualizer() {
        this.initialize();
    }

    private void initialize() {
        this.setSize(1200, 800);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setTitle("Kruskal's Algorithm Visualizer");
        this.setLocationRelativeTo(null);
        this.setLayout(new BorderLayout());

        this.kruskalPanel = new KruskalPanel();
        this.add(this.kruskalPanel, BorderLayout.CENTER);
          JPanel inputPanel = new JPanel();
//         inputPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        this.nodesTextField = new JTextField(5);
        JButton addNodesButton = new JButton("Add Nodes");
        addNodesButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                KruskalVisualizer.this.handleAddNodes();
            }
        });

        this.edgeSrcTextField = new JTextField(5);
        this.edgeDestTextField = new JTextField(5);
        this.edgeWeightTextField = new JTextField(5);
        JButton addEdgeButton = new JButton("Add/Remove Edge");
        addEdgeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                KruskalVisualizer.this.handleAddEdge();
            }
        });

        this.deleteNodeTextField = new JTextField(5);
        JButton deleteNodeButton = new JButton("Delete Node");
        deleteNodeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                KruskalVisualizer.this.handleDeleteNode();
            }
        });

        gbc.gridx = 0;
        gbc.gridy = 0;
        inputPanel.add(new JLabel("No. of Nodes"), gbc);
        gbc.gridx = 1;
        inputPanel.add(this.nodesTextField, gbc);
        gbc.gridx = 2;
        inputPanel.add(addNodesButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        inputPanel.add(new JLabel("Source Node:"), gbc);
        gbc.gridx = 1;
        inputPanel.add(this.edgeSrcTextField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        inputPanel.add(new JLabel("Destination Node:"), gbc);
        gbc.gridx = 1;
        inputPanel.add(this.edgeDestTextField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        inputPanel.add(new JLabel("Weight of Edge:"), gbc);
        gbc.gridx = 1;
        inputPanel.add(this.edgeWeightTextField, gbc);
        gbc.gridx = 2;
        inputPanel.add(addEdgeButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        inputPanel.add(new JLabel("Node to Delete:"), gbc);
        gbc.gridx = 1;
        inputPanel.add(this.deleteNodeTextField, gbc);
        gbc.gridx = 2;
        inputPanel.add(deleteNodeButton, gbc);

        this.add(inputPanel, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel(new GridBagLayout());

        JButton startButton = new JButton("Start Kruskal's Algorithm");
        startButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (KruskalVisualizer.this.V > 0) {
                    KruskalVisualizer.this.runKruskalAlgorithm();
                } else {
                    JOptionPane.showMessageDialog(KruskalVisualizer.this, "Please add nodes first");
                }
            }
        });

        JButton resetButton = new JButton("Restart");
        resetButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                KruskalVisualizer.this.reset();
            }
        });

        this.totalCostLabel = new JLabel("Total Cost is= 0");

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        buttonPanel.add(startButton, gbc);
        gbc.gridy = 1;
        buttonPanel.add(resetButton, gbc);
        gbc.gridy = 2;
        buttonPanel.add(this.totalCostLabel, gbc);

        this.add(buttonPanel, BorderLayout.SOUTH);

        this.setVisible(true);
    }

    private void handleAddNodes() {
        int numberOfNodes = Integer.parseInt(this.nodesTextField.getText());
        if (numberOfNodes > 0) {
            this.V = numberOfNodes;
            this.parent = new int[this.V];
            this.rank = new int[this.V];
            this.kruskalPanel.setNodeSize(Math.min(800 / this.V, 60));
            this.kruskalPanel.setNumberOfNodes(this.V);
            this.kruskalPanel.repaint();
        }
    }

    private void handleAddEdge() {
        if (this.V > 0) {
            int src = Integer.parseInt(this.edgeSrcTextField.getText());
            int dest = Integer.parseInt(this.edgeDestTextField.getText());
            int weight = Integer.parseInt(this.edgeWeightTextField.getText());

            if (weight < 0) {
                JOptionPane.showMessageDialog(this, "Weight cannot be negative");
                return;
            }

            if (src >= 0 && src < this.V && dest >= 0 && dest < this.V) {
                if (src == dest) {
                    JOptionPane.showMessageDialog(this, "Cannot add a self loop");
                    return;
                }

                Edge newEdge = new Edge(src, dest, weight);
                Iterator<Edge> iterator = this.edges.iterator();
                while (iterator.hasNext()) {
                    Edge edge = iterator.next();
                    if ((edge.src == src && edge.dest == dest) || (edge.src == dest && edge.dest == src)) {
                        iterator.remove();
                        JOptionPane.showMessageDialog(this, "Existing edge removed");
                        break;
                    }
                }
                this.edges.add(newEdge);
                JOptionPane.showMessageDialog(this, "Edge added");
                this.kruskalPanel.repaint();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid node indices");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please add nodes first");
        }
    }

    private void handleDeleteNode() {
        if (this.V > 0) {
            int node = Integer.parseInt(this.deleteNodeTextField.getText());
            if (node >= 0 && node < this.V) {
                Iterator<Edge> iterator = this.edges.iterator();
                while (iterator.hasNext()) {
                    Edge edge = iterator.next();
                    if (edge.src == node || edge.dest == node) {
                        iterator.remove();
                    }
                }
                for (int i = node; i < this.V - 1; i++) {
                    this.parent[i] = this.parent[i + 1];
                    this.rank[i] = this.rank[i + 1];
                }
                this.V--;
                this.kruskalPanel.setNumberOfNodes(this.V);
                this.kruskalPanel.repaint();
                JOptionPane.showMessageDialog(this, "Node and its edges removed");
            } else {
                JOptionPane.showMessageDialog(this, "Invalid node index");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please add nodes first");
        }
    }

    private void runKruskalAlgorithm() {
        new Thread(new Runnable() {
            public void run() {
                Collections.sort(KruskalVisualizer.this.edges, (e1, e2) -> Integer.compare(e1.weight, e2.weight));

                for (int i = 0; i < KruskalVisualizer.this.V; ++i) {
                    KruskalVisualizer.this.makeSet(i);
                }

                for (Edge edge : KruskalVisualizer.this.edges) {
                    int rootSrc = KruskalVisualizer.this.findSet(edge.src);
                    int rootDest = KruskalVisualizer.this.findSet(edge.dest);
                    if (rootSrc != rootDest) {
                        KruskalVisualizer.this.mstEdges.add(edge);
                        KruskalVisualizer.this.totalCost += edge.weight;
                        KruskalVisualizer.this.updateTotalCostLabel();
                        KruskalVisualizer.this.union(rootSrc, rootDest);
                        KruskalVisualizer.this.repaint();

                        try {
                            Thread.sleep(1000L);
                        } catch (InterruptedException var6) {
                            var6.printStackTrace();
                        }
                    }
                }
            }
        }).start();
    }

    private void makeSet(int v) {
        this.parent[v] = v;
        this.rank[v] = 0;
    }

    private int findSet(int v) {
        if (v != this.parent[v]) {
            this.parent[v] = this.findSet(this.parent[v]);
        }
        return this.parent[v];
    }

    private void union(int root1, int root2) {
        if (this.rank[root1] < this.rank[root2]) {
            this.parent[root1] = root2;
        } else if (this.rank[root1] > this.rank[root2]) {
            this.parent[root2] = root1;
        } else {
            this.parent[root1] = root2;
            this.rank[root2]++;
        }
    }

    private void updateTotalCostLabel() {
        this.totalCostLabel.setText("Total Cost: " + this.totalCost);
    }

    private void reset() {
        this.edges.clear();
        this.mstEdges.clear();
        this.totalCost = 0;
        this.updateTotalCostLabel();
        this.kruskalPanel.repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new KruskalVisualizer();
        });
    }

    class KruskalPanel extends JPanel {
        private int nodeSize;
        private int numberOfNodes;

        public KruskalPanel() {
            this.nodeSize = 60;
        }

        public void setNodeSize(int newSize) {
            this.nodeSize = newSize;
        }

        public void setNumberOfNodes(int numberOfNodes) {
            this.numberOfNodes = numberOfNodes;
        }

        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            this.drawGraph(g, KruskalVisualizer.this.edges, Color.BLACK);
            this.drawMST(g, KruskalVisualizer.this.mstEdges, Color.RED);
        }

        private void drawGraph(Graphics g, List<Edge> edges, Color color) {
            g.setColor(Color.BLACK);
            int centerX = this.getWidth() / 2;
            int centerY = this.getHeight() / 2;
            double radius = Math.min(centerX, centerY) * 0.8;

            for (int i = 0; i < this.numberOfNodes; ++i) {
                double angle = 2 * Math.PI * i / this.numberOfNodes;
                int x = (int) (centerX + radius * Math.cos(angle));
                int y = (int) (centerY + radius * Math.sin(angle));
                g.fillOval(x - this.nodeSize / 2, y - this.nodeSize / 2, this.nodeSize, this.nodeSize);
                g.setColor(Color.WHITE);
                g.drawString(String.valueOf(i), x, y);
                g.setColor(Color.BLACK);
            }

            for (Edge edge : edges) {
                int x1 = (int) (centerX + radius * Math.cos(2 * Math.PI * edge.src / this.numberOfNodes));
                int y1 = (int) (centerY + radius * Math.sin(2 * Math.PI * edge.src / this.numberOfNodes));
                int x2 = (int) (centerX + radius * Math.cos(2 * Math.PI * edge.dest / this.numberOfNodes));
                int y2 = (int) (centerY + radius * Math.sin(2 * Math.PI * edge.dest / this.numberOfNodes));
                g.drawLine(x1, y1, x2, y2);
                g.drawString(String.valueOf(edge.weight), (x1 + x2) / 2, (y1 + y2) / 2);
            }
        }

        private void drawMST(Graphics g, List<Edge> edges, Color color) {
            g.setColor(color);
            int centerX = this.getWidth() / 2;
            int centerY = this.getHeight() / 2;
            double radius = Math.min(centerX, centerY) * 0.8;

            for (Edge edge : edges) {
                int x1 = (int) (centerX + radius * Math.cos(2 * Math.PI * edge.src / this.numberOfNodes));
                int y1 = (int) (centerY + radius * Math.sin(2 * Math.PI * edge.src / this.numberOfNodes));
                int x2 = (int) (centerX + radius * Math.cos(2 * Math.PI * edge.dest / this.numberOfNodes));
                int y2 = (int) (centerY + radius * Math.sin(2 * Math.PI * edge.dest / this.numberOfNodes));
                g.drawLine(x1, y1, x2, y2);
                g.drawString(String.valueOf(edge.weight), (x1 + x2) / 2, (y1 + y2) / 2);
            }
        }
    }

    class Edge {
        int src, dest, weight;
        Edge(int src, int dest, int weight) {
            this.src = src;
            this.dest = dest;
            this.weight = weight;
        }
    }
}
